from .errorlogger import logger

if __name__ == "__main__":
    logger.error("this is a error message")
